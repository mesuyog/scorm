This folder contains a number of different sets of files:

Packaged
Contains the packaged files (from the source folder) for both SCORM 1.2 and SCORM 2004.  The Non-PIF folder contains all of the files that are used to import/play the Captivate in a SCORM-compliant environment.  These files are uncompressed - according to the SCORM standard.  The PIF folder/file is a compressed (zipped) version of the Non-PIF folder - where the imsmanifest.xml has to reside in the root of the .zip file.  In some LMSs, you can just reference the HTM file of the content, other LMSs allow you to import or reference the IMSManifest.xml file and some LMSs allow you to import the PIF file.  Contact your LMS Administrator for more information.

Publishing Template
This folder contains updated template files used when publishing content for SCORM (an option in the Quiz Manager).  They include up to two changes.   Two template files have been updated.  Both files have been updated to include references to supporting files used during content communication.  In addition, after Captivate was released, a questionable issue was reported about the manifest that is created for SCORM 2004.  The content still sends properly formatted SCORM data to an LMS and the manifest that is created will probably work in most LMS environments.  However, a change may be required to have the manifest file pass the SCORM 2004 Test Suite, without copying the XSD [and related] files to your desktop.  This folder contains an updated SCORM 2004 Manifest file, which can replace an existing file installed with Captivate, to ensure the content maifest will pass the SCORM 2004 Test Suite, without any additional steps.

Source
Contains the source files of Captivate content that is created for SCORM-tracking.  This gives you an idea of what the source files look like.  Please review the packaged folder, so you'll know what packaged files you'll need to deploy for successful integration with your SCORm-compliant LMS.  


