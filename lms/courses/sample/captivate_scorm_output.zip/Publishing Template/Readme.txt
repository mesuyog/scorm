The two files in this folder are updated Template files used by Captivate during the publish process, when "SCORM" is selected in the Quiz Manager.  The files contain up to two changes from the original shipping template files:

Both files contain additional <file> references to the supporting files that are required for content communication.  These references include the files contained in the "SCORM_support" folder.

After Captivate was released, a questionable issue was reported about the manifest that is created for SCORM 2004.  The content still sends properly formatted SCORM data to an LMS and the manifest that is created will probably work in most LMS environments.  However, a change may be required to have the manifest file pass the SCORM 2004 Test Suite, without copying the XSD [and related] files to your desktop.  An updated SCORM 2004 Manifest file is available as part of the example files.  

To use these updated template files:

1. Backup the existing files ("manifest.xml" and "manifest2004.xml") where Captivate is installed.  Typically you can find these files in the folder: �C:\Program Files\Macromedia\Captivate\Templates\Publish\�
2.  Copy the files "manifest.xml" and �manifest2004.xml�
3.  Paste the file (replace the existing file) where Captivate is installed.  Typically this folder is: �C:\Program Files\Macromedia\Captivate\Templates\Publish\�
4.  Publish the content for SCORM
